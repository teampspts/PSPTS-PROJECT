import React from "react";
import CalculateEmployeeSalaries from "./Calculate_Employee_Salaries/CalculateEmployeeSalaries";


export const Services = () => {
return (
	<div className="">
	{/* <h1>Calculate Salaries</h1> */}
	</div>
);
};

export const CalculateEmpSalaries = () => {
return (
	<div className="services">
	<CalculateEmployeeSalaries/>
	</div>
);
};

export const ServicesTwo = () => {
return (
	<div className="services">
	<h1>report2</h1>
	</div>
);
};

export const ServicesThree = () => {
return (
	<div className="services">
	<h1> report3</h1>
	</div>
);
};

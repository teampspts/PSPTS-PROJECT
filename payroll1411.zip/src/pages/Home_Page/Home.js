import React from "react";
import "./Home.css";

const Home = () => {
  return (
  <div className="home-bg1">
    <h3>Dash Board</h3>
    <div className="employeeList">
      <p>Total Number Of Employees </p>
      

    </div>
  </div>
  );
};

export default Home;

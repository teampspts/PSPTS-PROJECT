import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import payrollImage from "../../assets/payroll_image.png";
import logo from "../../assets/pakricornlogo.png";
import "./AdminLogin.css";
import { toast } from "react-toastify";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { replace } from "formik";

function AdminLogin() {
  const [userId, setuserId] = useState("");
  const [password, setPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const navigate = useNavigate();

  // Validation function to check if the password is at least 6 characters long
  const validatePassword = () => {
    if (password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
    } else {
      setPasswordError("");
    }
  };

  /////////////////////// Submit/////////////////
  async function login(event) {
    event.preventDefault();
    validatePassword();

    if (!userId) {
      alert("User ID is mandatory");
      return;
    }

    if (passwordError) {
      // Password validation failed, don't proceed with login
      return;
    }
    try {
      await axios
        .post("http://localhost:8889/admin/login/login", {
          userId: userId,
          password: password,
        })
        .then(
          (res) => {
            console.log(res.data);
            if(res.data.message=="Login Success"){
              toast.success("Login Successful");
              navigate("/home",{replace :true});
            }

            //  else if (res.data.message == "Login Failed") {
            //  toast.error("Login Failed");
             
            // } 
            else {
              toast.error("Incorrect userId and Password not match");
            }
          },
          (fail) => {
            console.error(fail); // Error!
          }
        );
    } catch (err) {
      alert(err);
    }
  }

  return (
    <div>
      <ToastContainer position="top-center" autoClose={3000} />
      <section className="vh-100">
        <div className="container-fluid h-custom">
          <div className="row d-flex justify-content-center align-items-center h-100">
            {/********* leftside image******** */}
            <div className="col-md-9 col-lg-6 col-xl-5">
              <img
                src={payrollImage}
                className="img-fluid"
                alt="Sample image"
              />
            </div>
            <div className="col-md-8 col-lg-6 col-xl-4 offset-xl-1 ">
              <div className="text-center ">
                <img
                  src={logo}
                  style={{ height: "50px", width: "350px" }}
                  alt="logo"
                  className="mb-2 pb-1"
                />
                <h4 
                style={{color:"green", fontFamily:"cursive",fontSize:"1.4rem"}}
                className="mt-1 mb-3 pb-1">Technology Pampered</h4>
              </div>
              {/* Form Starts */}
              <form className="border border-3 border-warning rounded p-4 mb-2">
                <h2 className="text-center mb-3" style={{ color: "#ff8c1a" }}>
                  Login
                </h2>

                <div className="form-outline mb-4 ">
                  <input
                    type="userId"
                    class="form-control"
                    id="userId"
                    placeholder="Enter User Id"
                    value={userId}
                    onChange={(event) => {
                      setuserId(event.target.value);
                    }}
                    onBlur={validatePassword} // Validate on blur
                  />
                </div>

                <div className="form-outline mb-3 ">
                  <input
                    type="password"
                    class="form-control"
                    id="password"
                    placeholder="Enter Password"
                    value={password}
                    onChange={(event) => {
                      setPassword(event.target.value);
                    }}
                  />
                  {passwordError && (
                    <div className="text-danger">{passwordError}</div>
                  )}
                </div>

                <div className="d-flex justify-content-between align-items-center">
                  {/* Check Box  */}
                  <div className="form-check mb-0">
                    <input
                      className="form-check-input me-2"
                      type="checkbox"
                      value=""
                      id="form2Example3"
                    />
                    <label className="form-check-label" htmlFor="form2Example3">
                      Remember me
                    </label>
                  </div>
                  <div>
                    <a href="#!" className="text-body">
                      Forgot password?
                    </a>
                  </div>
                </div>

                <div className="d-flex flex-column align-items-center text-center text-lg-start mt-4 pt-2">
                  <button
                    type="submit"
                    className="btn btn-primary btn-lg"
                    onClick={login}
                    style={{
                      paddingLeft: "2.5rem",
                      paddingRight: "2.5rem",
                    }}
                  >
                    Login
                  </button>
                  <p className="small fw-bold mt-2 pt-1 mb-0">
                    Don't have an account?{" "}
                    <a href="#!" className="link-danger">
                      Register
                    </a>
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default AdminLogin;

// import React from "react";
// import { Formik } from "formik";
// import { LoginSchema } from "../Validations/LoginSchema";
// const AdminLogin = () => {
//   const handleSubmit =(e)=>{
//     alert("ok");
//   }
//   return (
//     <div>
//       <Formik
//         initialValues={{
//           userId: "",
//           password: "",
//         }}
//         validationSchema={LoginSchema}
//         onSubmit={handleSubmit}
//       >
//         {(props) => {
//           const {
//             values,
//             touched,
//             errors,
//             isSubmitting,
//             handleChange,
//             handleBlur,
//             handleSubmit,
//           } = props;

//           return (
//             <div>
//               <h1>Login</h1>
//               <form onSubmit={handleSubmit}>
//                 <label htmlFor="userId">User Id</label>
//                 <input
//                   id="userId"
//                   name="userId"
//                   type="text"
//                   value={values.userId}
//                   onChange={handleChange}
//                   onBlur={handleBlur}
//                 />
//                 <label htmlFor="password">Password</label>
//                 <input
//                   id="password"
//                   name="password"
//                   type="password"
//                   value={values.password}
//                   onChange={handleChange}
//                   onBlur={handleBlur}
//                 />
//                 <button type="submit" disabled={isSubmitting}>
//                   Login
//                 </button>
//               </form>
//             </div>
//           );
//         }}
//       </Formik>
//     </div>
//   );
// };

// export default AdminLogin;

// import React from "react";
// import payrollImage from "../../assets/payroll_image.png";
// import logo from "../../assets/pakricornlogo.png";
// import "./AdminLogin.css";
// import { Formik } from "formik";
// import { LoginSchema } from "../Validations/LoginSchema";

// const AdminLogin = () => {
//   const handleSubmit = (e, { resetForm }) => {
//     e.preventDefault();
//     resetForm();
//   };

//   const LoginButton = (values) => {
//     console.log(values);
//     alert(
//       "Form data: User ID - " +
//         values.userId +
//         ", Password - " +
//         values.password
//     );

//   };

//   return (
//     <section className="vh-100">
//       <div className="container-fluid h-custom">
//         <div className="row d-flex justify-content-center align-items-center h-100">
{
  /********* leftside image******** */
}
// <div className="col-md-9 col-lg-6 col-xl-5">
//   <img src={payrollImage} className="img-fluid" alt="Sample image" />
// </div>
// <div className="col-md-8 col-lg-6 col-xl-4 offset-xl-1 ">
//   <div className="text-center ">
//     <img
//       src={logo}
//       style={{ height: "50px", width: "300px" }}
//       alt="logo"
//       className="mb-2 pb-1"
//     />
//     <h4 className="mt-1 mb-3 pb-1">We are The Pakricorn Team</h4>
//   </div>

{
  /* *****Form Starts***********/
}
// <Formik
//   initialValues={{
//     userId: "",
//     password: "",
//   }}
//   validationSchema={LoginSchema}
//   onSubmit={handleSubmit}
// >
//   {(props) => {
//     const {
//       values,
//       handleChange,
//       handleSubmit,
//       handleBlur,
//       touched,
//       errors,
//     } = props;
//     return (
//       <form
//         className="border border-3 border-warning rounded p-4 mb-2"
//         onSubmit={handleSubmit}
//       >
//         <h2
//           className="text-center mb-3"
//           style={{ color: "#ff8c1a" }}
//         >
//           Login
//         </h2>

//         <div className="">
{
  /* <!-- userIdAddress input --> */
}
{
  /* <div className="form-outline mb-4 ">
                        <input
                          type="userId"
                          name="userIdAddress"
                          id="form3Example3"
                          value={values.userIdAddress}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          className=" form-control form-control-lg"
                          placeholder="userId address"
                        />
                        {errors.userIdAddress && touched.userIdAddress && (
                          <div className="input-feedback">
                            {errors.userIdAddress}
                          </div>
                        )}
                      </div> */
}

{
  /* User Id Input */
}

// <div className="form-outline mb-4 ">
//   <input
//     type="text"
//     name="userId"
//     id="form3Example3"
//     value={values.userId}
//     onChange={handleChange}
//     onBlur={handleBlur}
//     className=" form-control form-control-lg"
//     placeholder="User Id"
//   />
//   {errors.userId && touched.userId && (
//     <div className="input-feedback">{errors.userId}</div>
//   )}
// </div>

{
  /* <!-- Password input --> */
}
// <div className="form-outline mb-3">
//   <input
//     type="password"
//     name="password"
//     id="form3Example4"
//     value={values.password}
//     onChange={handleChange}
//     onBlur={handleBlur}
//     className=" form-control form-control-lg"
//     placeholder="Enter password"
//   />
//   {errors.password && touched.password && (
//     <div className="input-feedback">
//       {errors.password}
//     </div>
//   )}
// </div>

// <div className="d-flex justify-content-between align-items-center">
{
  /* <!-- Checkbox --> */
}
//                   <div className="form-check mb-0">
//                     <input
//                       className="form-check-input me-2"
//                       type="checkbox"
//                       value=""
//                       id="form2Example3"
//                     />
//                     <label
//                       className="form-check-label"
//                       htmlFor="form2Example3"
//                     >
//                       Remember me
//                     </label>
//                   </div>
//                   <div>
//                     <a href="#!" className="text-body">
//                       Forgot password?
//                     </a>
//                   </div>
//                 </div>

//                 <div className="d-flex flex-column align-items-center text-center text-lg-start mt-4 pt-2">
//                   <button
//                     type="submit"
//                     className="btn btn-primary btn-lg"
//                     onClick={() => LoginButton(values)}
//                     style={{
//                       paddingLeft: "2.5rem",
//                       paddingRight: "2.5rem",
//                     }}
//                   >
//                     Login
//                   </button>
//                   <p className="small fw-bold mt-2 pt-1 mb-0">
//                     Don't have an account?{" "}
//                     <a href="#!" className="link-danger">
//                       Register
//                     </a>
//                   </p>
//                 </div>
//               </div>
//             </form>
//           );
//         }}
//       </Formik>
//     </div>
//   </div>
// </div>

{
  /* <!-- Right --> */
}
{
  /* </div> */
}
//     </section>
//   );
// };

// export default AdminLogin;

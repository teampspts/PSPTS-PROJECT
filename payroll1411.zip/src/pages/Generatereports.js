import React from "react";

export const Events = () => {
return (
	<div className="events">
	<h1> Generate letter</h1>
	</div>
);
};

export const EventsOne = () => {
return (
	<div className="events">
	<h1> letter1</h1>
	</div>
);
};

export const EventsTwo = () => {
return (
	<div className="events">
	<h1> letter2</h1>
	</div>
);
};

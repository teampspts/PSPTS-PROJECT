// import React from "react";
// import AddEmployeeDetails from "./AddEmployeeDetails";
// import UpdatingEmployeeDetails from "./UpdatingEmployeeDetails";
// import ViewEmployeeDetails from "./ViewEmployeeDetails";
// import DeleteEmployeeDetails from "./DeleteEmployeeDetails";
// export const Employees = () => {
//   return (
//     <div className="main-page">
//       <h1>Welcome Admin</h1>
//       <div className="home-data">
//         <div className="bg-img"></div>
//         <div>
        
//         </div>
//       </div>
//     </div>
//   );
// };

// export const Addemployee = () => {
//   return (
//     <div className="home">
//       <AddEmployeeDetails />
//     </div>
//   );
// };

// export const Updateemployee = () => {
//   return (
//     <div className="home">
//       <UpdatingEmployeeDetails />
//     </div>
//   );
// };

// export const Viewemployee = () => {
//   return (
//     <div className="home">
//       <ViewEmployeeDetails />
//     </div>
//   );
// };

// export const Deleteemployee = () => {
//   return (
//     <div className="home">
//       <DeleteEmployeeDetails />
//     </div>
//   );
// };

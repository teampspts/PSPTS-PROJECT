# Letter Generator


## About
Letter Generator is an website where an user can generate any type of letter whether it can be an offer letter, internship letter, application letter etc. By filing the details in the input field. It is also flexible in the sense that all the input fields are not required while generating the pdf so that it can be done as per the needs.

(P.S: Open in laptop or desktop for best experience)

## Screenshots
![1](https://user-images.githubusercontent.com/68656122/150932098-a6685ff0-21d5-411f-a2f9-ad074c91dc31.png)

![2](https://user-images.githubusercontent.com/68656122/151293687-5b70fda6-7b5f-4dd4-9eec-f375c68f7c3e.png)
